MINIPACK DOCUMENTATION

===========
Loading Bar
===========

# ft_progress(list)
fonction that takes a list and print information about the progress of the iterative loop on the list

Information are time elapsed , estimated time remaining, curent iteration number on the total number of iteration as well as a bar in percents descibing the progress

=============
Cofee Machine
=============

--------------------
class CofeeMachine()
--------------------

Create a class framing the functionement of a cofee machine with some water level (initialized at 100) and capable of making some cofee by spending 20 water level

# start_machine()
Start the machine with at minimum 20 water level

# boil_water()
Simply print that water is boiling

# make_cofee()

spend 20 water level to make some cofee  in aproximately 2 seconds

# add_water(water_level)
Increse the water level  of the cofee machine by the amount of water_level

--------------
Logger system
--------------

As the cofee machine is running, informations about its execution is strored in the machine.log file on the current folder.
Informations are the person operating, the functionality used and the time of exectution of the operation

## exemple

(xsaulnie)Running: Start Machine  [ exec-time = 0.003 ms ]
