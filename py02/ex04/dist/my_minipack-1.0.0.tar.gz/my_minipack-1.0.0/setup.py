import setuptools

setuptools.setup(
    name="my_minipack",
    version="1.0.0",
    author="xsaulnie 42 student",
    description="logger of cofee manchine with loading bar package",
    packages=["my_minipack"]
)