from .loading import ft_progress
from .logger import CoffeeMachine